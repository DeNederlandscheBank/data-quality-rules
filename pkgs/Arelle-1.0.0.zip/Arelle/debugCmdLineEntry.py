from arelle.CntlrGenVersReports import main

main()