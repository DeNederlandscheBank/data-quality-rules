'''
This module represents the time stamp when Arelle was last built

@author: Mark V Systems Limited
(c) Copyright 2018 Mark V Systems Limited, All rights reserved.

'''
__version__ = '1.2018.01.06'  # number version of code base and date compiled
version = '2018-01-06 20:15 UTC'  # string version of date compiled
copyrightLatestYear = '2018'  # string version of year compiled
