=======
Credits
=======

Development Lead
----------------

| Willem Jan Willemse <w.j.willemse@dnb.nl>
| Expert Centre on Data Analysis & Operational Management
| Division Insurance Supervision
| De Nederlandsche Bank (DNB)

Contributors
------------

* Annick van Ool
* Céline Hameleers

Your name could be here, see how to `contribute <https://github.com/DeNederlandscheBank/data-patterns/blob/master/CONTRIBUTING.rst>`_
