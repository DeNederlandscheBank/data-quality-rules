# -*- coding: utf-8 -*-
"""winpty module tests."""
